import React from 'react';
import { AutoComplete } from '@bit/primefaces.primereact.autocomplete';


class VilleRun extends React.Component {
	constructor() {
		super();
		this.state = {
			Ville: null
		};
		
	}

    render(){
        return <div>Truc temtem c'est génial!!!!</div>
    }
    

}

export default VilleRun; 